class Display{
    constructor(ctx) {
        this.myCtx=ctx;
        this.amplada=10
        this.alcada=3;
    }


}